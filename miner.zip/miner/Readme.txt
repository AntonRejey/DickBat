You need to run the "GUI Miner" for starting to mine.

This program is safe!
Some of the antivirus/internet security tools have marked the mining as not safe. If you get any warning, please turn off your antivirus program and try again!